


select 
	name, 
	detected_usages, 
	last_usage_date, 
	last_sample_date
from 
	dba_feature_usage_statistics
where 
	name in 
	(
		'ADDM', 'Automatic SQL Tuning Advisor', 'Automatic Workload Repository',
		'AWR Baseline', 'AWR Baseline Template', 'AWR Report', 'EM Performance Page',
		'Real-Time SQL Monitoring', 'SQL Access Advisor',
		'SQL Monitoring and Tuning pages', 'SQL Performance Analyzer',
		'SQL Tuning Advisor', 'SQL Tuning Set (system)', 'SQL Tuning Set (user)'
	)
order by name;

col name format A30
col detected format 9999
col samples format 9999
col used format A5
col interval format 9999999

SELECT 
	name,
	detected_usages detected,
	total_samples   samples,
	currently_used  used,
	to_char(last_sample_date,'MMDDYYYY:HH24:MI') last_sample,
	sample_interval interval
FROM 
	dba_feature_usage_statistics
WHERE 
	name = 'Automatic Workload Repository';

--alter system set control_management_pack_access = none;