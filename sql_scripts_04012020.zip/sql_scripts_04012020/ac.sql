REM --ac_days_to_expire.sql
REM --@ac_days_to_expire.sql
set linesize 200
set pagesize 200
col username format a20
col profile format a20
col PASSWORD_CHANGED_TIME format a22
col expiry_date format a18
select
        du.username,
        account_status,
        du.profile,
        --du.created,
        pw.ptime as PASSWORD_CHANGED_TIME,
        to_char(du.expiry_date, 'DD-MON-YY HH24:MI:SS') as expiry_date,
        round((du.expiry_date-sysdate)) as Days_to_expire
from
        dba_users du,
        (select
                name,
                to_char(PTIME,'DD-MON-YY HH24:MI:SS') as ptime from sys.user$
        where
                name not in
                        (  'ANONYMOUS', 'CTXSYS',   'DBSNMP', 'EXFSYS', 'LBACSYS',
                           'MDSYS',     'MGMT_VIEW','OLAPSYS','OWBSYS', 'ORDPLUGINS',
                           'ORDSYS',    'OUTLN',    'SI_INFORMTN_SCHEMA','SYS',
                           'SYSMAN',    'SYSTEM',   'TSMSYS', 'WK_TEST', 'WKSYS',
                           'WKPROXY',   'WMSYS',    'XDB', 'BI','HR','OE','PM','IX','SH',
                          'APEX_PUBLIC_USER','DIP',   'FLOWS_30000','FLOWS_FILES','MDDATA',
                           'ORACLE_OCM',      'PUBLIC','SPATIAL_CSW_ADMIN_USER',
                           'SPATIAL_WFS_ADMIN_USR', 'XS$NULL',
                           'APPQOSSYS','ORDDATA','SPATIAL_CSW_ADMIN_USR','APEX_030200','OWBSYS_AUDIT','SCOTT',
                           'SYSDG','AUDSYS','SYSRAC','SYSBACKUP','SYSKM','GSMADMIN_INTERNAL','GSMUSER',
                           'REMOTE_SCHEDULER_AGENT','DBSFWUSER','SYS$UMF','GSMCATUSER','GGSYS','OJVMSYS','DVF','DVSYS')
                and
                name not like ('%00%')
                and
                name not in('DBUTILS','TOAD','MONITOR_UNIX','QUEST_PA','WPS_VALIDATE','WPS_VALIDATE_USER','WPS_REPRICER_USER','WPS_REPRICER','NPPES','FOGLIGHT')
                and
                name not like 'RJJJ%'
                --and
                --name not in (select role from dba_roles)) pw
                and
                name not like '%$%') pw
where
        du.username=pw.name
order by
        profile, username;