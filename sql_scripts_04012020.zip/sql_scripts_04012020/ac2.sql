--REM Account status
set linesize 200
set pagesize 200
col username format a26
col account_status format a16
col created_date format a20
col lock_date format a20
col expiry_date format a20
col profile format a10
select 
	username, 
	profile,
	account_status, 
	--to_char(created, 'HH24:Mi:SS DD-MON-YY') as created_date,
	to_char(EXPIRY_DATE, 'HH24:Mi:SS DD-MON-YY') as expiry_date
	--to_char(LOCK_DATE, 'HH24:Mi:SS DD-MON-YY') as lock_date
from 
	dba_users 
order by created;