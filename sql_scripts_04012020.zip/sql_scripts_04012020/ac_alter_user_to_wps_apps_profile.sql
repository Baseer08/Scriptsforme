--REM ac_alter_user_to_wps_apps_profile.sql
Select 
	'alter user ' || username ||' profile WPS_APP ' ||';' 
from 
	dba_users 
where 
	username not in 
			('ANONYMOUS', 'CTXSYS',   'DBSNMP', 'EXFSYS', 'LBACSYS',
			   'MDSYS',     'MGMT_VIEW','OLAPSYS','OWBSYS', 'ORDPLUGINS', 
			   'ORDSYS',    'OUTLN',    'SI_INFORMTN_SCHEMA','SYS', 
			   'SYSMAN',    'SYSTEM',   'TSMSYS', 'WK_TEST', 'WKSYS',
			   'WKPROXY',   'WMSYS',    'XDB', 'BI','HR','OE','PM','IX','SH', 
			  'APEX_PUBLIC_USER','DIP',   'FLOWS_30000','FLOWS_FILES','MDDATA',
			   'ORACLE_OCM',      'PUBLIC','SPATIAL_CSW_ADMIN_USER',
			   'SPATIAL_WFS_ADMIN_USR', 'XS$NULL',
			   'APPQOSSYS','ORDDATA','SPATIAL_CSW_ADMIN_USR','APEX_030200','OWBSYS_AUDIT','SCOTT', 
			   'SYSDG','AUDSYS','SYSRAC','SYSBACKUP','SYSKM','GSMADMIN_INTERNAL','GSMUSER',
			   'REMOTE_SCHEDULER_AGENT','DBSFWUSER','SYS$UMF','GSMCATUSER','GGSYS','OJVMSYS','DVF','DVSYS')
		and
		username not like ('%00%')
		and
		username not in('DBUTILS','TOAD','MONITOR_UNIX','CCM_ORACLE_SCAN_SVC','QUEST_PA','WPS_VALIDATE','WPS_VALIDATE_USER','WPS_REPRICER_USER','WPS_REPRICER','NPPES','PERFSTAT')
		and
		username not like 'RJJJ%'
		and
		username not like '%$%'
order by
	username;