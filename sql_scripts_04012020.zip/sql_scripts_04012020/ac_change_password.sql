accept passwd char prompt "Enter new pasword: "

select 
	'alter user '||username||' identified by &&passwd account unlock;' as alter_user_for_new_password
from 
	dba_users 
where 
	username like 'TI%';