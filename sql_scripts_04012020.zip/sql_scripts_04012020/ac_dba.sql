REM --ac_days_to_expire.sql
REM --@ac_days_to_expire.sql
set linesize 200
set pagesize 200
col username format a20
col profile format a16
col PASSWORD_CHANGED_TIME format a22
col expiry_date format a22
select
	du.username,
	account_status,
	du.profile,
	--du.created,
	pw.ptime as PASSWORD_CHANGED_TIME,
	to_char(du.expiry_date, 'DD-MON-YY HH24:MI:SS') as expiry_date,
	round((du.expiry_date-sysdate)) as Days_to_expire
from
	dba_users du,
	(select 
		name,
		to_char(PTIME,'DD-MON-YY HH24:MI:SS') as ptime from sys.user$ 
	where 
		name like ('%00%')
		and
		name not like 'APEX%') pw
where
	du.username=pw.name
order by 
	username;