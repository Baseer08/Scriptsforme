set linesize 200
        set pagesize 200
        select
                (select name from v$database) as DBNAME, username, default_tablespace, TEMPORARY_TABLESPACE from dba_users
        where
                DEFAULT_TABLESPACE='USERS'
        order by
                username;