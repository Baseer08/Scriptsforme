set linesize 200
set pagesize 200
col inst_id format 9999999
col username format a14
col machine format a30
break on inst_id skip 1
select 
	(select name from v$database) as DBNAME,
	inst_id,
	USERNAME,
	MACHINE,
	STATUS,
	to_char(LOGON_TIME, 'DD-MON-YY HH24:MI-SS') as logon_time,
	--LAST_CALL_ET INACTIVE_SECONDS,
	round(LAST_CALL_ET/60,2) INACTIVE_MNs,
	round(LAST_CALL_ET/60/60,2) inactive_HRs
from  
	gv$session 
where 
	username in (select username from dba_users where profile='WPS_APP')
	and 
	LAST_CALL_ET > 7200
	and
	status='INACTIVE'
order by 
	inst_id,
	LAST_CALL_ET desc;