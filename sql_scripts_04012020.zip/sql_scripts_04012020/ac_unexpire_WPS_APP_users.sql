--REM ac_unexpire_WPS_APP_users.sql
alter profile WPS_APP limit PASSWORD_REUSE_TIME UNLIMITED;
alter profile WPS_APP limit PASSWORD_REUSE_MAX UNLIMITED;

@ac.sql

set linesize 2000
set pagesize 2000
set echo off
SET FEEDBACK OFF
SET FEED OFF
SET VERIFY OFF
set heading off
set wrap off
SET NEWPAGE NONE
set colsep ,     	
set pagesize 0   	
set trimspool on 	
set headsep off  	  	
set numw 10	
spool /tmp/unexpire.sql
SELECT 
	'ALTER USER '|| name ||' IDENTIFIED BY VALUES '''|| spare4 ||';'|| password ||''';'  as command_to_execute
FROM 
	sys.user$ 
WHERE 
	name in 
			(select username from dba_users where profile='WPS_APP');
spool off

@/tmp/unexpire.sql

alter profile WPS_APP limit PASSWORD_REUSE_TIME 60;
alter profile WPS_APP limit PASSWORD_REUSE_MAX 10;
alter profile WPS_APP limit PASSWORD_LIFE_TIME 60;

@ac.sql