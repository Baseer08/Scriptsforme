--REM @ac_unexpire_user.sql
--alter profile &&PROFILE_NAME limit PASSWORD_REUSE_TIME UNLIMITED;
--alter profile &&PROFILE_NAME limit PASSWORD_REUSE_MAX UNLIMITED;


set linesize 140
set pagesize 200
set echo off
SET FEEDBACK OFF
SET FEED OFF
SET VERIFY OFF
set heading off
set wrap off
SET NEWPAGE NONE
set colsep ,     	
set pagesize 0   	
set trimspool on 	
set headsep off  	  	
set numw 10	
spool /tmp/unexpire.sql
SELECT 
	'ALTER USER '|| name ||' IDENTIFIED BY VALUES '''|| spare4 ||';'|| password ||''';'  as command_to_execute
FROM 
	sys.user$ 
WHERE 
	name in 
			(select username from dba_users where profile='&&PROFILE_NAME');
spool off


--alter profile &&PROFILE_NAME limit PASSWORD_REUSE_TIME 60;
--alter profile &&PROFILE_NAME limit PASSWORD_REUSE_MAX 10;
--alter profile &&PROFILE_NAME limit PASSWORD_LIFE_TIME 60;


/*
set linesize 140
set pagesize 200
SELECT 
	'ALTER USER '|| name ||' IDENTIFIED BY VALUES '''|| spare4 ||';'|| password ||''';'  as command_to_execute
FROM 
	sys.user$ 
WHERE 
	name not in 
			(  'ANONYMOUS', 'CTXSYS',   'DBSNMP', 'EXFSYS', 'LBACSYS',
			   'MDSYS',     'MGMT_VIEW','OLAPSYS','OWBSYS', 'ORDPLUGINS', 
			   'ORDSYS',    'OUTLN',    'SI_INFORMTN_SCHEMA','SYS', 
			   'SYSMAN',    'SYSTEM',   'TSMSYS', 'WK_TEST', 'WKSYS',
			   'WKPROXY',   'WMSYS',    'XDB', 'BI','HR','OE','PM','IX','SH', 
			   'APEX_PUBLIC_USER','DIP',   'FLOWS_30000','FLOWS_FILES','MDDATA',
			   'ORACLE_OCM',      'PUBLIC','SPATIAL_CSW_ADMIN_USER',
			   'SPATIAL_WFS_ADMIN_USR', 'XS$NULL',
			   'APPQOSSYS','ORDDATA','SPATIAL_CSW_ADMIN_USR','APEX_030200','OWBSYS_AUDIT','SCOTT', 
			   'SYSDG','AUDSYS','SYSRAC','SYSBACKUP','SYSKM','GSMADMIN_INTERNAL','GSMUSER',
			   'REMOTE_SCHEDULER_AGENT','DBSFWUSER','SYS$UMF','GSMCATUSER','GGSYS','OJVMSYS','DVF','DVSYS')
	and
	name not like ('%00%')
	and
	name not in('DBUTILS','TOAD','MONITOR_UNIX','QUEST_PA','WPS_VALIDATE','WPS_VALIDATE_USER','WPS_REPRICER_USER','WPS_REPRICER','NPPES','PERFSTAT')
	and
	name not like 'RJJJ%'
	and
	name not in (select role from dba_roles)
	and
	name <> '_NEXT_USER'
	and 
	name not like '%$%';
*/