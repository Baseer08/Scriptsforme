--REM Account with profile
set linesize 200
set pagesize 200
col username format a26
col account_status format a16
col created_date format a20
col lock_date format a20
col expiry_date format a20
select 
	username, 
	account_status, 
	--to_char(created, 'HH24:Mi:SS DD-MON-YY') as created_date,
	--to_char(LOCK_DATE, 'HH24:Mi:SS DD-MON-YY') as lock_date,
	--to_char(EXPIRY_DATE, 'HH24:Mi:SS DD-MON-YY') as expiry_date,
	profile
from 
	dba_users 
where 
	username not in 
		('ANONYMOUS', 'CTXSYS',   'DBSNMP', 'EXFSYS', 'LBACSYS',
		   'MDSYS',     'MGMT_VIEW','OLAPSYS','OWBSYS', 'ORDPLUGINS', 
		   'ORDSYS',    'OUTLN',    'SI_INFORMTN_SCHEMA','SYS', 
		   'SYSMAN',    'SYSTEM',   'TSMSYS', 'WK_TEST', 'WKSYS',
		   'WKPROXY',   'WMSYS',    'XDB', 'BI','HR','OE','PM','IX','SH', 
		  'APEX_PUBLIC_USER','DIP',   'FLOWS_30000','FLOWS_FILES','MDDATA',
		   'ORACLE_OCM',      'PUBLIC','SPATIAL_CSW_ADMIN_USER',
		   'SPATIAL_WFS_ADMIN_USR', 'XS$NULL',
		   'APPQOSSYS','ORDDATA','SPATIAL_CSW_ADMIN_USR','APEX_030200','OWBSYS_AUDIT','SCOTT', 
		   'SYSDG','AUDSYS','SYSRAC','SYSBACKUP','SYSKM','GSMADMIN_INTERNAL','GSMUSER',
		   'REMOTE_SCHEDULER_AGENT','DBSFWUSER','SYS$UMF','GSMCATUSER','GGSYS','OJVMSYS','DVF','DVSYS')
order by created;