set linesize 200
set pagesize 200
col name format a80
select
	name,
	sequence#,
	to_char(first_time, 'DD-MM-YYYY HH24:MI:SS') as first_time,
	status
from
	v$archived_log
where
	status <> 'D'
order by
	sequence#;