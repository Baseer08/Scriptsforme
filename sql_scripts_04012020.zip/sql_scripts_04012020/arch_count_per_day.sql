set linesize 200
set pagesize 200
SELECT  A.*,
        Round(A.Count#*B.AVG#) Daily_archived_GB, round(A.count#*C.AVG#/1024/1024/1024) daily_redo_space_GB
FROM
        (SELECT
            To_Char(First_Time,'MM-DD-YY   :Dy') DAY,
            Count(*) Count#,
            Min(RECID) Min#,
            Max(RECID) Max#
        FROM
            v$log_history
        GROUP BY
            To_Char(First_Time,'MM-DD-YY   :Dy')
        ORDER BY 1 DESC) A,
        (SELECT
            avg(round(block_size * blocks/1024/1024/1024,2)) avg#
        FROM
            v$archived_log) B,
        (SELECT
            Avg(BYTES) AVG#
        from
            v$log) C
order by 1;