-- @arch_minmaxavg.sql
select  
	'Minimum/day (MB): '|| Round(min(round(sum(BLOCKS*BLOCK_SIZE)/1024/1024)),2) Archivelog_Generation_MB
from 
	v$archived_log 
where 
	completion_time > sysdate-30
group by 
	trunc(COMPLETION_TIME,'DD'),thread# 	
union
select  
	'Maximum/day (MB): '|| Round(max(round(sum(BLOCKS*BLOCK_SIZE)/1024/1024)),2) Archivelog_Generation_MB
from 
	v$archived_log 
where 
	completion_time > sysdate-30
group by 
	trunc(COMPLETION_TIME,'DD'),thread# 
union
select  
	'Average/day (MB): '|| Round(avg(round(sum(BLOCKS*BLOCK_SIZE)/1024/1024)),2) Archivelog_Generation_MB
from 
	v$archived_log 
where 
	completion_time > sysdate-30
group by 
	trunc(COMPLETION_TIME,'DD'),thread# 
order by 1;

/*
REM Get Last 30 days archivelog stats
col size_in_MB format 999,999.99
SELECT 
	TRUNC(COMPLETION_TIME) ARCHIVED_DATE,
	Round(SUM(BLOCKS * BLOCK_SIZE) / 1024 / 1024,2) SIZE_IN_MB
FROM 
	V$ARCHIVED_LOG
where 
	completion_time > sysdate-30
GROUP BY 
	TRUNC(COMPLETION_TIME)
ORDER BY 2;
*/