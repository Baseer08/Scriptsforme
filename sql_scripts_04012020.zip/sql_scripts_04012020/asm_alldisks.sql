break on diskgroup_name skip 1
set linesize 200
set pagesize 500
col disk_name format a50
select
    d.group_number,
    dg.name as diskgroup_name,
    d.name as disk_name,
    round(d.total_mb/1024,2) as size_GB
from     
    V$asm_disk d,
    v$asm_diskgroup dg
where
    d.group_number=dg.group_number
order by 1,2,3;

set linesize 200
col DG_NAME format a12
col DISK_NAME format a12
col Failgroup format a15
break on DG_Name skip 1
select b.name as DG_NAME,
a.disk_number,
a.name as Disk_NAME,
round(a.total_MB/1024,2) TS_in_GB,
round(a.free_MB/1024,2) FS_in_GB,
--a.mode_status,
--a.state,
--a.header_status,
b.type as Redundancy,
a.failgroup,
b.REQUIRED_MIRROR_FREE_MB,
round(b.required_mirror_free_mb/a.total_mb,0) as Disks_needed4Mirroring
from V$asm_disk a,
v$asm_diskgroup b
where a.group_number=b.group_number
--and b.name='DATA’
order by b.name, a.disk_number;

