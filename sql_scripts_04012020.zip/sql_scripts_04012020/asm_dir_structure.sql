set pages 2000
SELECT 
	level, 
	dir, 
	sys, 
	substr(lpad(' ',2*level,' ')||CONCAT('+'||gname, SYS_CONNECT_BY_PATH(aname,'/')),1,60) full_path
FROM 
	( 
		SELECT 
			g.name gname, 
			a.parent_index pindex, 
			a.name aname,
			a.reference_index rindex, 
			a.ALIAS_DIRECTORY dir, 
			a.SYSTEM_CREATED sys
		FROM 
			v$asm_alias a, 
			v$asm_diskgroup g
		WHERE 
			a.group_number = g.group_number
	)
START WITH 
	(MOD(pindex, POWER(2, 24))) = 0
CONNECT BY 
	PRIOR rindex = pindex
ORDER BY 
	rtrim(ltrim(full_path)) desc, 
	level asc;