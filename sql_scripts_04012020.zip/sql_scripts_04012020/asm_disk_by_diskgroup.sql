clear scr
select name from v$asm_diskgroup;
break on diskgroup_name skip 1
set linesize 200
set pagesize 500
col disk_name format a50
select
	d.DISK_NUMBER,
    d.group_number,
    dg.name as diskgroup_name,
    d.name as disk_name,
    round(d.total_mb/1024,2) as size_GB
from     
    V$asm_disk d,
    v$asm_diskgroup dg
where
    d.group_number=dg.group_number
	and dg.name='&DISK_GROUP'
order by 1,4;