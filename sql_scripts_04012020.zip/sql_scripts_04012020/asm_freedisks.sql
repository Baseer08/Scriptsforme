col name format a14
col path format a40
set linesize 200
select 
--group_number,  
--state, 
name, 
path, 
--MOUNT_STATUS, 
HEADER_STATUS, 
MODE_STATUS,
disk_number from v$asm_disk 
where header_status in ('FORMER', 'CANDIDATE', 'PROVISIONED')
order by path, disk_number;

