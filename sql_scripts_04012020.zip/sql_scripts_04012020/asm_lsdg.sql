/*set pagesize 200
set linesize 200
col name format a20
col "%_Free" format a10
col "%_Used" format a10
col Total_GB format 9999999.99
select
        name,
        round((round(total_mb,2)-round(free_mb,2))/1024,2) as USED_GB,
		round(free_mb/1024/1024,2) as FREE_TB,
        round(total_mb/1024/1024,2) as TOTAL_TB,
		--round((free_mb/1024/1024)/3,2) as Usable_FREE_TB,
		--round((total_mb/1024/1024)/3,2) as Usable_TOTAL_TB,
        round((free_mb/total_mb)*100,2) || '%' as "%_Free",
        100-(round((free_mb/total_mb)*100,2)) ||'%'  as "%_Used",
		Round(USABLE_FILE_MB/1024/1024,2) as USABLE_FILE_TB
from
        v$asm_diskgroup
order by
        4;*/

set linesize 200
col name format a20
col "%_Free" format a10
col "%_Used" format a10
col Total_GB format 9999999.99
break on Info skip 1
select
		'Without Mirroring ' as Info,
        name,
        round((round(total_mb,2)-round(free_mb,2))/1024/1024,2) as USED_TB,
		round(free_mb/1024/1024,2) as FREE_TB,
        round(total_mb/1024/1024,2) as TOTAL_TB,
        round((free_mb/total_mb)*100,2) || '%' as "%_Free",
        100-(round((free_mb/total_mb)*100,2)) ||'%'  as "%_Used"
from
        v$asm_diskgroup
union all
select
		'With tripple Mirroring: ' as Info,
        name,
        round(((round(total_mb,2)-round(free_mb,2))/1024/1024)/3,2) as USED_TB,
		round((free_mb/1024/1024)/3,2) as FREE_TB,
        round((total_mb/1024/1024)/3,2) as TOTAL_TB,
        round((free_mb/total_mb)*100,2) || '%' as "%_Free",
        100-(round((free_mb/total_mb)*100,2)) ||'%'  as "%_Used"
from
        v$asm_diskgroup;


