set linesize 200
set pagesize 200
col path format a60
select 
	name, 
	path 
from 
	v$asm_disk 
order by 
	name;

