set lines 250 pages 1000 
col error_code form a10 
col name format a10
SELECT 
	dg.name, 
	o.* 
FROM 
	gv$asm_operation o, 
	v$asm_diskgroup dg 
WHERE 
	o.group_number = dg.group_number;