SET FEEDBACK OFF
SET VERIFY OFF
set linesize 120
col name format a10
col asm_usage format a40
define PERC = &1
with
        DB as
                (select name from v$database),
        ASM as
                (select
                     'ASM Disk: '||Name ||' is '|| PUSED ||'%  Used. ' as ASM_Usage
                from
					(
					select 
						name, 
						round((round(total_mb,2)-round(free_mb,2))/1024,2) as USED_GB, 
						round(free_mb/1024,2) as FREE_GB, 
						round(total_mb/1024,2) as TOTAL_GB,
						round((free_mb/total_mb)*100,2) as PFREE,
						100-(round((free_mb/total_mb)*100,2))  as PUSED
					from 
						v$asm_diskgroup
					)
                where
                     PUSED > &PERC)
select
        DB.name as DBName,
        ASM.ASM_Usage
from
        DB,
        ASM;