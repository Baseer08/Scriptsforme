set linesize 200
set pagesize 200
col name format a30
col value format a50
select name, value from v$parameter where name='db_block_size';
clear columns