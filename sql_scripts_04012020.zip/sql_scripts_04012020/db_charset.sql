set linesize 200
set pagesize 200
col parameter format a40
col value format a40
select * from nls_database_parameters;
select * from nls_database_parameters where parameter='NLS_CHARACTERSET';
clear col