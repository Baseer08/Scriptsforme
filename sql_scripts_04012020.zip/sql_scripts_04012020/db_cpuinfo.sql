col c1 heading '#|CPUs'        format 999
col c2 heading '#|CPU|Cores'   format 999
col c3 heading '#|CPU|Sockets' format 999
select
   (select max(value) from dba_hist_osstat 
    where stat_name = 'NUM_CPUS')        c1,
   (select max(value) from dba_hist_osstat 
    where stat_name = 'NUM_CPU_CORES')   c2,
   (select max(value) from dba_hist_osstat 
    where stat_name = 'NUM_CPU_SOCKETS') c3
from dual;