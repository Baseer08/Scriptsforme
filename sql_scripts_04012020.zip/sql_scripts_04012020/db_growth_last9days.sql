with group1 as (select /*+ materialize parallel(t,2) ordered */
   to_char(s.begin_interval_time,'yyyy-mm-dd') get_date,
   v.name ts_name,
(round(max((t.tablespace_size*(select value from v$parameter where name='db_block_size')))/1024/1024/1024,2)) size_gb,
(round(max((tablespace_usedsize*(select value from v$parameter where name='db_block_size')))/1024/1024/1024,2)) used_gb
from 
   dba_hist_tbspc_space_usage t, 
   v$tablespace               v, 
   dba_hist_snapshot          s
where 
   t.tablespace_id=v.ts#
and 
   t.snap_id=s.snap_id
group by to_char(s.begin_interval_time,'yyyy-mm-dd'), v.name)
select 
   get_date, 
   sum(size_gb) tot_size,
   sum(used_gb) used_size
from 
   group1
group by get_date
order by get_date;