set linesize 200
set pagesize 200
col name format a30
col value format a50
select name, value/1024/1024/1024 as value_GB from v$parameter where name='pga_aggregate_limit';
clear columns