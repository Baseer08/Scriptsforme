col size_GB format 99999.99
select round(sum(bytes)/1024/1024/1024,2) as size_GB from v$datafile;