select (select 'Space_GIVEN_to_DB' from dual) as Note,
round(sum(d.bytes)/1024/1024/1024 + (sum(t.bytes)/1024/1024/1024),2) as Size_in_GB  
from
v$datafile d,
v$tempfile t
where
d.file#=t.file#(+)
group by 1
union
select
(select 'Space_USED_by_DB' from dual) as Note,
round(sum(size_in_bytes)/1024/1024/1024,2) Size_in_GB
from
(select
tablespace_name, 
sum(bytes) size_in_bytes
from 
dba_segments
group by 
tablespace_name)
group by 1
union
select
(select 'Data_USED_by_DB' from dual) as Note,
round(sum(size_in_bytes)/1024/1024/1024,2) Size_in_GB
from
(select 
tablespace_name, 
sum(bytes) size_in_bytes
from
dba_segments
where segment_type not in ('INDEX','LOBSEGMENT','LOBINDEX','TYPE2 UNDO')
group by
tablespace_name)
group by 1
union
select
(select 'Data_Index_USED_by_DB' from dual) as Note,
round(sum(size_in_bytes)/1024/1024/1024,2) Size_in_GB
from
(select 
tablespace_name, 
sum(bytes) size_in_bytes
from 
dba_segments
where segment_type='INDEX'
group by  
tablespace_name)
group by 1
union
select
(select 'LOB_Data_USED_by_DB' from dual) as Note,
round(sum(size_in_bytes)/1024/1024/1024,2) Size_in_GB
from
(select 
tablespace_name, 
sum(bytes) size_in_bytes
from 
dba_segments
where segment_type='LOBSEGMENT'
group by 
tablespace_name)
group by 1
union
select
(select 'LOB INDEX_USED_by_DB' from dual) as Note,
round(sum(size_in_bytes)/1024/1024/1024,2) Size_in_GB
from
(select 
tablespace_name, 
sum(bytes) size_in_bytes
from 
dba_segments
where segment_type='LOBINDEX'
group by 
tablespace_name)
group by 1
union
select
(select 'UNDO_USED_by_DB' from dual) as Note,
round(sum(size_in_bytes)/1024/1024/1024,2) Size_in_GB
from
(select 
tablespace_name,
sum(bytes) size_in_bytes
from 
dba_segments
where segment_type='TYPE2 UNDO'
group by 
tablespace_name)
group by 1
order by 2;
