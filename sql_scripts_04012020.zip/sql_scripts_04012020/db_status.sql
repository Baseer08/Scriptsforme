col Inst_name format a10
col host_name format a24
col status format a6
col startup_time format a20
select instance_name as inst_name, host_name, status, to_char(STARTUP_TIME, 'DD-MON-YY HH24:MI:SS') as startup_time from gv$instance;