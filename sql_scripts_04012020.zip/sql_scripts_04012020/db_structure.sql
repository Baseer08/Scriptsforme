REM Author: Moid Muhammad
REM Description: Get Database file Location
REM Version: 1.0
REM Date: 5/8/18
REM Last Updated: 5/8/18


set linesize 200
set pagesize 200
col name format a60
Col "No." format 99
col value format a40
break on filename
clear screen
with datastructure as 
	(
		select 'Control File: ' as fileName, Rownum as "No.", name from v$controlfile
		union all
		select 'Data File:  ' as fileName, Rownum as "No.", name from v$datafile
		union all
		select 'Temp File: ' as fileName, Rownum as "No.", name from V$tempfile
		union all
		select 'Redo Logs: ' as fileName, Rownum as "No.", member from V$logfile
		union all
		select 'Archive Logs: ' as fileName, Rownum as "No.", substr(value,10) from v$parameter where name like 'log_archive_dest_%' and name not like '%state%' and value is not null
		union all
		select 'FRA: ' as filename, Rownum as "No.", value from v$parameter where name like 'db_recovery_file_dest'
	)
select * from datastructure;