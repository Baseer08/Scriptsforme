set linesize 200
set pagesize 200
REM Undo Usage
REM ********************************

select tablespace_name,status,count(*)
from dba_undo_extents
group by tablespace_name,status;

REM Undo User and Size Usage
REM ********************************
select 
	u.tablespace_name tablespace, 
	s.username, 
	u.status, 
	sum(u.bytes)/1024/1024 sum_in_mb, 
	count(u.segment_name) seg_cnts 
from 
	dba_undo_extents u 
	left join v$transaction t on u.segment_name = '_SYSSMU' || t.xidusn || '$' 
	left join v$session s on t.addr = s.taddr 
group by 
	u.tablespace_name, 
	s.username, 
	u.status 
order by 
	1,2,3;

REM Undo Free space
REM ********************************
select 
	a.tablespace_name, 
	SIZEMB, USAGEMB, 
	(SIZEMB - USAGEMB) FREEMB
from 
	(
		select 
			sum(bytes) / 1024 / 1024 SIZEMB, 
			b.tablespace_name
		from 
			dba_data_files a, 
			dba_tablespaces b
		where 
			a.tablespace_name = b.tablespace_name
			and 
			b.contents = 'UNDO'
		group by 
			b.tablespace_name
	) a,
	(
		select 
			c.tablespace_name, 
			sum(bytes) / 1024 / 1024 USAGEMB
		from 
			DBA_UNDO_EXTENTS c
		where 
			status <> 'EXPIRED'
		group by 
			c.tablespace_name
	) b
where 
	a.tablespace_name = b.tablespace_name;




















