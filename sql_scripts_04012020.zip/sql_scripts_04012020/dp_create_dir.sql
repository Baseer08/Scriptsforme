accept dbname char prompt 'Enter database name: '
!mkdir -p /rkb-mvh/datadump1/&dbname
set linesize 200
set pagesize 200
col directory_name format a30
col directory_path format a70
create directory test_mm as '/rkb-mvh/datadump1/&dbname';
select directory_name, directory_path from dba_directories where directory_name='TEST_MM';
!ls -ld /rkb-mvh/datadump1/&dbname