set linesize 200
set pagesize 200
col directory_name format a30
col directory_path format a70
select directory_name, directory_path from dba_directories order by 1;