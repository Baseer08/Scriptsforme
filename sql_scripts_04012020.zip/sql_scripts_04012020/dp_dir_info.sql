set linesize 200
set pagesize 200
col directory_name format a30
col directory_path format a70
select directory_name, directory_path from dba_directories
where directory_path not like '/u01%'
order by 1;