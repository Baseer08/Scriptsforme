set linesize 200
set pagesize 200
col owner format a20
col table_name format a40
select owner, table_name from dba_tables where table_name=upper('&table_name');