col name     format a32
col size_GB  format 999,999,999
col used_GB  format 999,999,999
col pct_used format 999
col reclaimable_GB for 999,999,999

SELECT name
, ceil( space_limit/1024/1024/1024) SIZE_GB
, ceil( space_used/1024/1024/1024) USEDGB
, ceil( space_reclaimable/1024/1024/1024) RECLAIMABLE_GB
, decode( nvl( space_used, 0), 0, 0 , ceil ( ( ( space_used - space_reclaimable ) / space_limit) * 100) ) PCT_USED
 FROM v$recovery_file_dest
ORDER BY name;


