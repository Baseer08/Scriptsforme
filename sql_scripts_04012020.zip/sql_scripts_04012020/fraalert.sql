SET FEEDBACK OFF
SET VERIFY OFF
set linesize 120
col name format a10
define PERC = &1
with
        DB as
                (select name from v$database),
        FRA as
                (select
                        'Flash Recovery Area is '|| PUSED ||'%  Used. ' as FRA_Usage
                from
					(
						select
								round(SPACE_LIMIT/1024/1024/1024,2) as SPACE_LIMIT_GB,
								round(SPACE_USED/1024/1024/1024,2) as SPACE_USED_GB,
								round(((SPACE_LIMIT/SPACE_USED)/SPACE_USED)*100,3) as PUSED,
								round(100-((SPACE_LIMIT/SPACE_USED)/SPACE_USED)*100,3) as PFREE
						from
								v$RECOVERY_FILE_DEST
					)
                where
                    PUSED > &PERC)
select
        DB.name as DBName,
        FRA.FRA_Usage
from
        DB,
        FRA;