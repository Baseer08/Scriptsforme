set long 20000 
set longchunksize 20000 
set pagesize 0 
set linesize 1000 
set feedback off 
set heading off;
set echo off;
set verify off 
set trimspool on
column ddl format a1000
begin
   dbms_metadata.set_transform_param (dbms_metadata.session_transform, 'SQLTERMINATOR', true);
   dbms_metadata.set_transform_param (dbms_metadata.session_transform, 'PRETTY', true);
end;
/

spool get_profile_ddl_results.sql
select dbms_metadata.get_ddl('PROFILE', profile) as profile_ddl
from   (select distinct profile
		from   dba_profiles);
spool off
set pagesize 14 linesize 80 feedback on heading on echo on verify on trimspool off