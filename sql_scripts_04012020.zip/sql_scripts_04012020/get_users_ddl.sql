set heading off;
set echo off;
set linesize 2000
set pagesize 2000
set long 20000 
set longchunksize 20000 
set feedback off 
set verify off 
set trimspool on
spool get_users_ddl_results.sql
select dbms_metadata.get_ddl('USER',username)||';' FROM dba_users
where username not in ('ANONYMOUS', 'CTXSYS',   'DBSNMP', 'EXFSYS', 'LBACSYS',
		   'MDSYS',     'MGMT_VIEW','OLAPSYS','OWBSYS', 'ORDPLUGINS', 
		   'ORDSYS',    'OUTLN',    'SI_INFORMTN_SCHEMA','SYS', 
		   'SYSMAN',    'SYSTEM',   'TSMSYS', 'WK_TEST', 'WKSYS',
		   'WKPROXY',   'WMSYS',    'XDB', 'BI','HR','OE','PM','IX','SH', 
		  'APEX_PUBLIC_USER','DIP',   'FLOWS_30000','FLOWS_FILES','MDDATA',
		   'ORACLE_OCM',      'PUBLIC','SPATIAL_CSW_ADMIN_USER',
		   'SPATIAL_WFS_ADMIN_USR', 'XS$NULL',
		   'APPQOSSYS','ORDDATA','SPATIAL_CSW_ADMIN_USR','APEX_030200','OWBSYS_AUDIT','SCOTT', 
		   'SYSDG','AUDSYS','SYSRAC','SYSBACKUP','SYSKM','GSMADMIN_INTERNAL','GSMUSER',
		   'REMOTE_SCHEDULER_AGENT','DBSFWUSER','SYS$UMF','GSMCATUSER','GGSYS','OJVMSYS','DVF','DVSYS')
order by username;
spool off
set linesize 80 pagesize 14 feedback on verify on heading on echo on trimspool off