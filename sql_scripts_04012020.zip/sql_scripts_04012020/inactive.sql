REM List inactive sessions older than 4 hours
set linesize 200
set pagesize 200
col username format a26
col expiry_date format a20
break on inst_id skip 1
select 
	inst_id, 
	username, 
	status,
	round(LAST_CALL_ET/60,2) INACTIVE_Mins,
	round(LAST_CALL_ET/60/60,2) INACTIVE_Hrs
from 
	gv$session 
where 
	username not in 
	('ANONYMOUS', 'CTXSYS',   'DBSNMP', 'EXFSYS', 'LBACSYS',
			   'MDSYS',     'MGMT_VIEW','OLAPSYS','OWBSYS', 'ORDPLUGINS', 
			   'ORDSYS',    'OUTLN',    'SI_INFORMTN_SCHEMA','SYS', 
			   'SYSMAN',    'SYSTEM',   'TSMSYS', 'WK_TEST', 'WKSYS',
			   'WKPROXY',   'WMSYS',    'XDB', 'BI','HR','OE','PM','IX','SH', 
			  'APEX_PUBLIC_USER','DIP',   'FLOWS_30000','FLOWS_FILES','MDDATA',
			   'ORACLE_OCM',      'PUBLIC','SPATIAL_CSW_ADMIN_USER',
			   'SPATIAL_WFS_ADMIN_USR', 'XS$NULL',
			   'APPQOSSYS','ORDDATA','SPATIAL_CSW_ADMIN_USR','APEX_030200','OWBSYS_AUDIT','SCOTT', 
			   'SYSDG','AUDSYS','SYSRAC','SYSBACKUP','SYSKM','GSMADMIN_INTERNAL','GSMUSER',
			   'REMOTE_SCHEDULER_AGENT','DBSFWUSER','SYS$UMF','GSMCATUSER','GGSYS','OJVMSYS','DVF','DVSYS','SYSRAC')
	and 
	status <> 'ACTIVE'
	and last_call_et > 60*60*4
	order by 1, 4 desc;