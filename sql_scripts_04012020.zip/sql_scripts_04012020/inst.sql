set linesize 200
set pagesize 200
col Inst_name format a10
col host_name format a20
select instance_name as inst_name, host_name, status from v$instance;