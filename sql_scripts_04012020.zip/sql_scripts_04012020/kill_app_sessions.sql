--@kill_app_sessions.sql
set linesize 800
set pagesize 200
select username, SID, Serial#, inst_id from GV$session 
where username not in ('SYS','SYSTEM','SYSMAN','DBSNMP');

select 'ALTER SYSTEM KILL SESSION '''||sid||','||serial#||',@'||inst_id||''' immediate;' as command2execute
from gv$session
where username not in ('SYS','SYSTEM','SYSMAN','DBSNMP');