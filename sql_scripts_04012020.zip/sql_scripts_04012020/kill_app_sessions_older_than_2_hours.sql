set linesize 200
set pagesize 200
col username format a20
col machine format a30
break on inst_id skip 1
select 
	inst_id,
	USERNAME,
	MACHINE,
	STATUS,
	to_char(LOGON_TIME, 'DD-MON-YY HH24:MI-SS') as logon_time,
	LAST_CALL_ET INACTIVE_SECONDS,
	round(LAST_CALL_ET/60,2) INACTIVE_Minutes,
	round(LAST_CALL_ET/60/60,2) inactive_hours
from  
	gv$session 
where 
	username in (select username from dba_users where profile='WPS_APP')
	and 
	LAST_CALL_ET > 7200
	and
	status='INACTIVE'
order by 
	inst_id,
	LAST_CALL_ET desc;
	
	

select 'ALTER SYSTEM KILL SESSION '''||sid||','||serial#||',@'||inst_id||''' immediate;' as Kill_command2execute
from gv$session
where username not in ('SYS','SYSTEM','SYSMAN','DBSNMP')
and 
username in (select username from dba_users where profile='WPS_APP')
	and 
	LAST_CALL_ET > 7200
order by 
	inst_id,
	LAST_CALL_ET desc;