set linesize 200
set pagesize 200
col username format a20
select 
	username, 
	account_status,
	to_char(lock_date, 'HH24:MI:SS DD-MON-YYYY') as lock_date,
	expiry_date 
from 
	dba_users 
where 
	(account_status like '%LOCKED%'
	or
	account_status like '%EXPIRED%')
	and
	username not in  
			(
			   'ANONYMOUS', 'CTXSYS',   'DBSNMP', 'EXFSYS', 'LBACSYS',
			   'MDSYS',     'MGMT_VIEW','OLAPSYS','OWBSYS', 'ORDPLUGINS', 
			   'ORDSYS',    'OUTLN',    'SI_INFORMTN_SCHEMA', 
			   'SYSMAN',    'TSMSYS', 'WK_TEST', 'WKSYS',
			   'WKPROXY',   'WMSYS',    'XDB', 'BI','HR','OE','PM','IX','SH', 
			  'APEX_PUBLIC_USER','DIP',   'FLOWS_30000','FLOWS_FILES','MDDATA',
			   'ORACLE_OCM',      'PUBLIC','SPATIAL_CSW_ADMIN_USER',
			   'SPATIAL_WFS_ADMIN_USR', 'XS$NULL',
			   'APPQOSSYS','ORDDATA','SPATIAL_CSW_ADMIN_USR','APEX_030200','OWBSYS_AUDIT',
			   'SCOTT', 'SYSDG','AUDSYS','SYSRAC','SYSBACKUP','SYSKM','GSMADMIN_INTERNAL',
			   'GSMUSER', 'REMOTE_SCHEDULER_AGENT','DBSFWUSER','SYS$UMF','GSMCATUSER',
			   'GGSYS','OJVMSYS','DVF','DVSYS','PERFSTAT'
			);