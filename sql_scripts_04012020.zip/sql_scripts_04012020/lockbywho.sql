REM create tablespace dbutils_tbs datafile '&datafile' size 1G autoextend on next 1G maxsize unlimited;
REM create user dbutils identified by "T3mPpAsS_T3mPpAsS_" profile WPS_MONITORING default tablespace dbutils_tbs;
REM grant connect, resource, unlimited tablespace to dbutils;
REM grant administer database trigger to dbutils;

REM CREATE TABLE dbutils.logon_trigger (USERNAME VARCHAR2(50),USERHOST VARCHAR2(128),TIMESTAMP DATE);

REM CREATE OR REPLACE TRIGGER dbutils.logon_trigger 
REM AFTER SERVERERROR ON DATABASE 
REM BEGIN IF (IS_SERVERERROR(1017)) 
REM THEN INSERT INTO logon_trigger VALUES(SYS_CONTEXT('USERENV', 'AUTHENTICATED_IDENTITY'), SYS_CONTEXT('USERENV', 'HOST'), SYSDATE); 
REM COMMIT;  
REM END IF;
REM END; 
REM /


set linesize 200
set pagesize 200
col USERHOST FOR a30
ALTER SESSION SET nls_date_format='DD-MON-YYYY HH24:mi:ss';
SELECT * FROM dbutils.logon_trigger ORDER BY TIMESTAMP;