clear scr
set linesize 200
set pagesize 200
col parameter format a30
col value format a40
select * from nls_database_parameters 
order by 1;

select * from nls_database_parameters 
where parameter in ('NLS_CHARACTERSET','NLS_LANGUAGE','NLS_TERRITORY')
order by 1;