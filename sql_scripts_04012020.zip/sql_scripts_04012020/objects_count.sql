clear scr
set linesize 200
set pagesize 200
col owner format a20
col object_type format a20
break on owner
select owner, object_type, count(*) from dba_objects 
where (owner like 'TI%' or owner like 'WPS%')
group by owner, object_type order by 1;