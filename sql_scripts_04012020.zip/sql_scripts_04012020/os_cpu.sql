set linesize 200
set pagesize 200
col stat_name format a30
col value format a16
SELECT
	STAT_NAME,
	DECODE
		(
			STAT_NAME,
				'PHYSICAL_MEMORY_BYTES',(ROUND(VALUE/1024/1024/1024,2))|| ' GB',
				'FREE_MEMORY_BYTES',(ROUND(VALUE/1024/1024/1024,2))|| ' GB',
				'SWAP_FREE_BYTES',(ROUND(VALUE/1024/1024/1024,2))|| ' GB',
			VALUE ) VALUE
	--comments
FROM
	v$osstat
WHERE
	stat_name IN ('NUM_CPUS', 'NUM_CPU_CORES','NUM_CPU_SOCKETS')
order by 
	1;