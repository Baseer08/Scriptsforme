--Top Running QuerieSELECT

set linesize 200
set pagesize 0
col first_load_time format a22
col last_load_time format a22
col SQL_FULLTEXT format a40
col SQL_TEXT format a70
SELECT * FROM
(SELECT
	sql_id,
	SQL_TEXT,
    --sql_fulltext,
    --elapsed_time as elapsed_time_ms,
	--elapsed_time/1000000 as elapsed_time_secs,
	round((elapsed_time/1000000)/60,2) as elapsed_time_mins,
    child_number,
    disk_reads,
    executions,
    first_load_time,
    last_load_time
FROM    v$sql
ORDER BY elapsed_time DESC)
WHERE ROWNUM < 20
/

--SELECT * FROM table(DBMS_XPLAN.DISPLAY_CURSOR('&sql_id', &child));