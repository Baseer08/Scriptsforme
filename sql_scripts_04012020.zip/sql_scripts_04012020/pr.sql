select max(sequence#), archived, decode (status, 'A', 'Available') as status from v$archived_log
where status='A'
group by archived, status;