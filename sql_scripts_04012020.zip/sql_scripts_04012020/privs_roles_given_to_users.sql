clear scr
set linesize 200
set pagesize 200
col grantee format a40
col granted_role format a40
break on grantee skip 1
select grantee, granted_role from dba_role_privs where grantee like 'SPOTFIRE%' order by 1;