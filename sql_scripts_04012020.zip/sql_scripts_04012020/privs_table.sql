--CHECK privileges on tables.
--desc dba_tab_privs
set linesize 200
set pagesize 200
col grantee format a20
col owner format a20
col table_name format a30
col grantor format a20
col privilege format a20
break on grantee on owner on table_name skip 1
select 
	grantee, 
	owner, 
	table_name, 
	grantor, 
	privilege 
from
	dba_tab_privs
where 
	table_name=upper('&table_name')
order by 
	owner, table_name;