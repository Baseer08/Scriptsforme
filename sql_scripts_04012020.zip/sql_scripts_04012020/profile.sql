set linesize 200
set pagesize 200
Break on profile Skip 1
col profile format a20
col resource_type format a20
col resource_name format a30
col limit format a30
select 
	profile, 
	resource_name, 
	resource_type, 
	limit 
from dba_profiles
order by 1,2;
clear scr
select distinct profile from dba_profiles;

select 
	profile, 
	resource_name, 
	resource_type, 
	limit 
from 
	dba_profiles
where profile=upper('&profile_name');
