set linesize 200
set pagesize 200
--Break on profile Skip 1
select 
	profile, 
	resource_name, 
	resource_type, 
	limit 
from 
	dba_profiles
where profile=upper('&profile_name');



select * from dba_profiles where profile in ('DEFAULT','SERVICE_ACCT') and  RESOURCE_NAME in ('PASSWORD_REUSE_TIME');


select * from dba_profiles where profile in ('DEFAULT','SERVICE_ACCT') and  RESOURCE_NAME in ('PASSWORD_LIFE_TIME');


REM alter profile DEFAULT limit PASSWORD_LIFE_TIME 180;
REM alter profile DEFAULT limit PASSWORD_GRACE_TIME unlimited;
REM alter profile DEFAULT limit PASSWORD_REUSE_MAX unlimited;