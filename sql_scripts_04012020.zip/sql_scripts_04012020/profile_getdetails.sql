set linesize 200
set pagesize 200
Break on profile Skip 1
select 
	profile, 
	resource_name, 
	resource_type, 
	limit 
from 
	dba_profiles
where profile='&profile';
