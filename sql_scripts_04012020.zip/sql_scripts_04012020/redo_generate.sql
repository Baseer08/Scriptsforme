SELECT  A.*,
        Round(A.Count#*B.AVG#) Daily_archived_Mb, round(A.count#*C.AVG#/1024/1024) daily_redo_space
FROM
        (SELECT
            To_Char(First_Time,'YYYY-MM-DD   :Dy') DAY,
            Count(1) Count#,
            Min(RECID) Min#,
            Max(RECID) Max#
        FROM
            v$log_history
        GROUP BY
            To_Char(First_Time,'YYYY-MM-DD   :Dy')
        ORDER BY 1 DESC) A,
        (SELECT
            avg(round(block_size * blocks/1024/1024,2)) avg#
        FROM
            v$archived_log) B,
        (SELECT
            Avg(BYTES) AVG#
        from
            v$log) C;
			
			

select 'Total Redo Generated in last 14 days: '|| round(sum(daily_archived_mb)/1024,2)||' GB' as Total
FROM
    (   SELECT
            A.*,
            Round(A.Count#*B.AVG#) Daily_archived_Mb,
            round(A.count#*C.AVG#/1024/1024) daily_redo_space
        FROM
            (   SELECT
                    To_Char(First_Time,'YYYY-MM-DD   :Dy') DAY_of_the_month,
                    Count(1) Count#,
                    Min(RECID) Min#,
                    Max(RECID) Max#
                FROM
                    v$log_history
                GROUP BY
                    To_Char(First_Time,'YYYY-MM-DD   :Dy')
                    ORDER BY 1 DESC
            ) A,
            (   SELECT
                    avg(round(block_size * blocks/1024/1024,2)) avg#
                FROM
                v$archived_log
            ) B,
            (   SELECT
                    Avg(BYTES) AVG# from
                    v$log
            ) C
        where rownum <= 14
    );





select 'Total Redo Generated in last 100 days: '|| round(sum(daily_archived_mb)/1024,2)||' GB' as Total
FROM
    (   SELECT
            A.*,
            Round(A.Count#*B.AVG#) Daily_archived_Mb,
            round(A.count#*C.AVG#/1024/1024) daily_redo_space
        FROM
            (   SELECT
                    To_Char(First_Time,'YYYY-MM-DD   :Dy') DAY_of_the_month,
                    Count(1) Count#,
                    Min(RECID) Min#,
                    Max(RECID) Max#
                FROM
                    v$log_history
                GROUP BY
                    To_Char(First_Time,'YYYY-MM-DD   :Dy')
                    ORDER BY 1 DESC
            ) A,
            (   SELECT
                    avg(round(block_size * blocks/1024/1024,2)) avg#
                FROM
                v$archived_log
            ) B,
            (   SELECT
                    Avg(BYTES) AVG# from
                    v$log
            ) C
        --where rownum <= 14
    );
