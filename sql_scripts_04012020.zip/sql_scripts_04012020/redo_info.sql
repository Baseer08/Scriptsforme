set linesize 200
set pagesize 200
column member format a60
Column group# format 99999
Column status format a8
column Size_MB format 999999
column "Archived?" format a9
Column SEQ# format 9999999
break on thread# skip 1
select
	b.thread#,
    a.group#,
    a.member,
    b.bytes/1024/1024 as Size_MB,
    b.status,
    b.archived as "Archived?",
    b.Sequence# as SEQ#,
    to_char(b.first_time, 'Mon-DD-YY HH24:Mi:SS') as Log_Switch_Time
from
    v$logfile a,
    v$log b
where a.group#=b.group#
order by 1,2,7;