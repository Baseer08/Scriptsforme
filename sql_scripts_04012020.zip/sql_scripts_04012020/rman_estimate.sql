set linesize 200
set pagesize 200
col dbsize_GB      for 99,999,990.00 justify right head "DBSIZE_GB"
col input_GB       for 99,999,990.00 justify right head "READ_GB"
col output_GB      for 99,999,990.00 justify right head "WRITTEN_GB"
col output_device_type for a10           justify left head "DEVICE"
col complete           for 990.00        justify right head "COMPLETE %" 
col compression        for 990.00        justify right head "COMPRESS|% ORIG"
col est_complete       for a20           head "ESTIMATED COMPLETION"
col recid              for 9999999       head "ID"
col event for a40
col client_info for a30

select 
	client_info,
	event 
from 
	v$session 
where 
	event like '%backup%'
order 
	by client_info;

select 
	recid, 
	output_device_type,
	dbsize_mbytes/1024 as dbsize_GB,
	input_bytes/1024/1024/1024 input_GB, 
	output_bytes/1024/1024/1024 output_GB, 
	(output_bytes/input_bytes*100) compression, 
	(mbytes_processed/dbsize_mbytes*100) complete, 
	to_char(start_time + (sysdate-start_time)/(mbytes_processed/dbsize_mbytes),'DD-MON-YYYY HH24:MI:SS') est_complete
from 
	v$rman_status rs, 
	(select sum(bytes)/1024/1024 dbsize_mbytes from v$datafile) 
where 
	status='RUNNING'
	and 
	output_device_type is not null;