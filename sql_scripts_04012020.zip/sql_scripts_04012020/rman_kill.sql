--Kill RMAN Backup

select 'alter system kill session ''' || SID || ',' || serial# || ''' immediate;'
from V$SESSION_LONGOPS
WHERE OPNAME LIKE 'RMAN%' AND OPNAME NOT LIKE '%aggregate%'
AND TOTALWORK! = 0 AND SOFAR <> TOTALWORK;