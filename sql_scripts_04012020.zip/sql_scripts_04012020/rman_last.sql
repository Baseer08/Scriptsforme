col STATUS format a9
col hrs format 99999.99
select 
	SESSION_KEY, 
	INPUT_TYPE, 
	STATUS,
	to_char(START_TIME,'mm/dd/yy hh24:mi') start_time,
	to_char(END_TIME,'mm/dd/yy hh24:mi') end_time,
	elapsed_seconds/3600 hrs 
from 
	V$RMAN_BACKUP_JOB_DETAILS
where 
	session_key in (select max(session_key) from v$rman_backup_job_details group by input_type)
order by 
	session_key;