set pagesize 2000
set linesize 2000
select 
	output
from 
	GV$RMAN_OUTPUT
where 
	session_recid = 
		(
			select 
				session_recid 
			from 
				V$RMAN_BACKUP_JOB_DETAILS
			where 
				session_key=(select max(session_key) from v$RMAN_BACKUP_JOB_DETAILS)
		);