clear scr
set linesize 200
set pagesize 200
col owner format a20
col table_name format a20
col Size_GB format 999,999.99
ttitle -
left 'Oracle Maintained Users' skip 1 - 
left '================================' skip 1
select 
	owner,
	Round(sum(bytes)/1024/1024/1024,2) as Size_GB
from 
	dba_segments 
where 
	owner in (select username from dba_users where oracle_maintained='Y')
group by 
	owner
order by 
	2 desc;


ttitle -
left 'Application Maintained Users' skip 1 - 
left '================================' skip 1
select 
	owner,
	Round(sum(bytes)/1024/1024/1024,2) as Size_GB
from 
	dba_segments 
where 
	owner not in (select username from dba_users where oracle_maintained='Y')
group by 
	owner
order by 
	2 desc;
ttitle off