set linesize 200
set pagesize 200

col owner format a16
col table_name format a16
col object_name format a16
col username format a16
col name format a16
col file_name format a30
col tablespace_name format a16
