REM 	Author: Moid Muhammad
REM 	Date: 02/06/2018
REM 	Last Update: 09/18/2019
REM		Description: Display list of users connected to databases.
REM		Version: 1.0
REM		Version: 1.1 | Add status column
REM		Version: 1.2 | Add gv$session
REM		
REM 		

set linesize 200
set pagesize 200
col username format a16
col terminal format a20
col machine format a30
col program format a40

select
	inst_id,
	username,
	terminal,
	machine,
	program,
	status
from 
	gv$session
where
	username is not null
order by 1;

break on inst_id skip 1
select
	inst_id,
	nvl(username,'Oracle Processes') as username, 
	machine,
	count(*)
from
	gv$session
group by
	inst_id,
	username,
	machine
order by
	1, 3;
	
select 
	inst_id,
	nvl(username,'Oracle Processes') as username, 
	status,
	count(*)
from
	gv$session
group by
	inst_id,
	username,
	status
order by
	1, 2;	