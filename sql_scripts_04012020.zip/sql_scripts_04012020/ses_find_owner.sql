col username format a20
col profile format a20
select 
user_id, 
username,
profile 
from 
dba_users
where 
user_id in 
(select user_id fROM v$active_session_history WHERE session_ID=&SID and session_serial#=&serial);