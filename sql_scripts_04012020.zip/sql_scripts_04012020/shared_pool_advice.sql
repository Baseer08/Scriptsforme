select shared_pool_size_for_estimate as estimate_size,
shared_pool_size_factor as factor,
estd_lc_time_saved as time_saved, estd_lc_load_time as load_time
from v$shared_pool_advice;