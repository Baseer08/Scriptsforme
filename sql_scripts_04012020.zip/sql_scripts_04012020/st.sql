break on thread# skip 1
select 
	thread#,
	max(sequence#),
	decode (status, 'A','Available','D','Deleted','U','Unavailable','X','Expired') as status,
	archived,
	applied
from
	v$archived_log
where
	status='A'
group by
	thread#,
	status,
	archived,
	applied
order by 
	1,2;
