clear scr
set linesize 200
set pagesize 100
break on owner on table_name
col table_owner format a16
col table_name format a25
col part_name format a20
col user_stats format a10
col stale_stats format a11
col sub_part format a20
break on owner on table_name
select
        table_owner,
        table_name,
        partition_name as part_name,
        SUBPARTITION_NAME as sub_part,
        inserts,
        updates,
        deletes,
        timestamp
from
        dba_tab_modifications
where
        table_owner in (select username from dba_users where oracle_maintained='N')
order by
        1, 2, 3;
