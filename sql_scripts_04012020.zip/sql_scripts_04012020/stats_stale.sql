clear scr
set linesize 200
set pagesize 200
break on owner on table_name
col owner format a16
col table_name format a25
col part_name format a20
col user_stats format a10
col stale_stats format a11
col sub_part format a20
select 
	owner, 
	table_name, 
	partition_name as part_name, 
	--partition_position as part_pos,
	SUBPARTITION_NAME as sub_part,
	--SUBPARTITION_POSITION as sub_part_pos,
	object_type, 
	--chain_cnt, 
	avg_row_len, 
	num_rows, 
	sample_size, 
	last_analyzed, 
	--user_stats, 
	stale_stats
from 
	dba_tab_statistics
where 
	owner in (select username from dba_users where oracle_maintained='N') and stale_stats='YES'
order by 
	1, 2, 3;