set linesize 200
set pagesize 200
col db_unique_name format a15
select name, db_unique_name, database_role, open_mode, protection_mode from v$database;

