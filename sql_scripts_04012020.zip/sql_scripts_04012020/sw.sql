alter system switch logfile;
