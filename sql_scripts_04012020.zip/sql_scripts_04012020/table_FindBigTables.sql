SET LINESIZE 200
SET PAGESIZE 200
COLUMN owner FORMAT A30
COLUMN segment_name FORMAT A30
COLUMN tablespace_name FORMAT A30
COLUMN size_mb FORMAT 999,999,99.00
COLUMN size_mb FORMAT 999,999,99.00

SELECT 
	*
FROM   
	(SELECT 
		owner,
		segment_name,
		segment_type,
		tablespace_name,
		ROUND(bytes/1024/1024,2) size_mb,
		ROUND(bytes/1024/1024/1024,2) size_gb
	FROM   
		dba_segments
	ORDER BY 
		5 DESC)
WHERE  
	ROWNUM <= 20;