set linesize 200
set pagesize 200
col owner format a16
col index_name format a36
col table_name format a36
col column_name format a36
select 
	b.owner,
	a.index_name, 
	a.table_name, 
	a.column_name,
	b.uniqueness
from 
	dba_ind_columns a, 
	dba_indexes b
where 
	b.owner=upper('&owner')
	and 
	a.table_name =upper('&table_name')
	and
	a.index_name=b.index_name 
order by 
	a.table_name, 
	a.index_name, 
	a.column_position;