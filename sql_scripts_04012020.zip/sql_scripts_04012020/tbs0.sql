set linesize 200
set pagesize 200
col reserved(GB) format 999,999.99
col used(GB) format 999,999.99
col free(GB) format 999,999.99
col pct_used format 999.99
break on Tablespace_type skip 1
select
   (select 'Tablespace: ' from dual) as Tablespace_type,
   b.tablespace_name as tablespacename,
   round(sum(b.bytes/1024/1024/1024) / count(distinct a.file_id ||'.' || a.block_id),2)  "RESERVED(GB)",
   round(sum(b.bytes/1024/1024/1024) /  count(distinct a.file_id || '.' || a.block_id) - sum(a.bytes/1024/1024/1024) / count(distinct b.file_id),2)  "USED(GB)",
   round(sum (a.bytes/1024/1024/1024) / count(distinct b.file_id),2) "FREE(GB)",
   round(100 * ((sum(b.bytes) / count(distinct a.file_id ||'.' || a.block_id)) - (SUM(a.bytes) / count(distinct b.file_id))) /(sum(b.bytes) / count(distinct a.file_id ||
'.' || a.block_id)),2) pct_used
from
   sys.dba_free_space a,
   sys.dba_data_files b
where
   b.tablespace_name = a.tablespace_name(+)
   and 
   b.tablespace_name not in (select distinct tablespace_name from dba_undo_extents)
group by
   B.tablespace_name 
union all
select
   (select 'Undo Tablespace: ' from dual) as Tablespace_type,
   b.tablespace_name as tablespacename,
   round(sum(b.bytes/1024/1024/1024) / count(distinct a.file_id ||'.' || a.block_id),2)  "RESERVED(GB)",
   round(sum(b.bytes/1024/1024/1024) /  count(distinct a.file_id || '.' || a.block_id) - sum(a.bytes/1024/1024/1024) / count(distinct b.file_id),2)  "USED(GB)",
   round(sum (a.bytes/1024/1024/1024) / count(distinct b.file_id),2) "FREE(GB)",
   round(100 * ((sum(b.bytes) / count(distinct a.file_id ||'.' || a.block_id)) - (SUM(a.bytes) / count(distinct b.file_id))) /(sum(b.bytes) / count(distinct a.file_id ||
'.' || a.block_id)),2) pct_used
from
   sys.dba_free_space a,
   sys.dba_data_files b
where
   b.tablespace_name = a.tablespace_name(+)
   and 
   b.tablespace_name in (select distinct tablespace_name from dba_undo_extents)
group by
   B.tablespace_name
union all
select
        (select 'Temporary Tablespace: ' from dual) as Tablespace_type,
        tablespace_name as tablespace_name,
        tablespace_size/1024/1024/1024 as "RESERVED(GB)",
        round(allocated_space/1024/1024/1024,2) as "USED(GB)",
        round(Free_space/1024/1024/1024,2) as Free_SPACE,
        Round((allocated_space/tablespace_size)*100,2) as PCT_USED
from
        DBA_TEMP_FREE_SPACE
order by 1,6 desc;
