col tablespace_name format a16
select 
	tablespace_name,
	round(Total_GB,2) as TOtal_GB,
	round(free_GB,2) as Free_GB,
	round(Used_GB,2) as Used_GB,
	PUsed,
	PFree
from
	(
	Select
		a.tablespace_name, 
		b.T_size/1024/1024/1024 as Total_GB,
		(b.t_size-a.f_size)/1024/1024/1024 as Used_GB,
		a.F_size/1024/1024/1024 as Free_GB,
		round(((b.t_size-a.f_size)/b.T_size)*100,2) as PUSED,
		100-round(((b.t_size-a.f_size)/b.T_size)*100,2) as PFree
	from
	(select tablespace_name, sum(bytes) as F_size from dba_free_space group by tablespace_name) a,
	(select tablespace_name, sum(bytes) as T_size from dba_data_files group by tablespace_name) b
	where
		a.tablespace_name=b.tablespace_name
	)
where
	PUSED > 80
order by 6;