SELECT 
	b.tsname tablespace_name, 
	MAX(b.used_size_mb) cur_used_size_mb, 
	round(AVG(inc_used_size_mb),2)avg_increase_mb_per_day 
FROM 
	(
		SELECT 
			a.days, 
			a.tsname, 
			used_size_mb, 
			used_size_mb - LAG (used_size_mb,1)  
				OVER ( PARTITION BY a.tsname ORDER BY a.tsname,a.days) inc_used_size_mb
		FROM (
			  SELECT 
				TO_CHAR(sp.begin_interval_time,'MM-DD-YYYY') days,
				ts.tsname,
				MAX(round((tsu.tablespace_usedsize* dt.block_size )/(1024*1024),2)) used_size_mb
			  FROM 
				DBA_HIST_TBSPC_SPACE_USAGE tsu, 
				DBA_HIST_TABLESPACE_STAT ts,
				DBA_HIST_SNAPSHOT sp, 
				DBA_TABLESPACES dt
			  WHERE 
				tsu.tablespace_id= ts.ts# 
				AND 
				tsu.snap_id = sp.snap_id
				AND 
				ts.tsname = dt.tablespace_name  
				AND 
				sp.begin_interval_time > sysdate-9
			  GROUP BY 
				TO_CHAR(sp.begin_interval_time,'MM-DD-YYYY'), 
				ts.tsname 
			  ORDER BY 
			  ts.tsname, 
			  days
			) A
	) b 
GROUP BY 
	b.tsname 
ORDER BY 
	b.tsname;