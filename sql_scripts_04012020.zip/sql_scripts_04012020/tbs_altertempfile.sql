SET PAGESIZE 60
SET LINESIZE 300
COLUMN TBS_NAME FORMAT A20
COLUMN FILENAME FORMAT A50
BREAK on TBS_NAME
col size_GB format 9,999.99
col Used_GB format 9,999.99
col Free_GB format 9,999.99
Col "% Used" format 999
col INC_GB format 99.99
col max_gb format 99.99
SELECT  
Substr(df.tablespace_name,1,20) as TBS_NAME,
        Substr(df.file_name,1,80) as FILENAME,
        Round(df.bytes/1024/1024/1024,0) SIZE_GB,
        decode(e.used_bytes,NULL,0,Round(e.used_bytes/1024/1024/1024,0)) as USED_GB,
        decode(f.free_bytes,NULL,0,Round(f.free_bytes/1024/1024/1024,0)) as FREE_GB,
        decode(e.used_bytes,NULL,0,Round((e.used_bytes/df.bytes)*100,2)) "% Used",
		df.AUTOEXTENSIBLE,
		round(df.INCREMENT_BY*(select value from v$parameter where name='db_block_size')/1024/1024/1024,2) as INC_GB,
		round(df.MAXBYTES/1024/1024/1024,2) as Max_GB
FROM    
	dba_temp_files DF,
       (SELECT file_id,
               sum(bytes) used_bytes
        FROM dba_extents
        GROUP by file_id) E,
       (SELECT Max(bytes) free_bytes,
               file_id
        FROM dba_free_space
        GROUP BY file_id) f
WHERE    
	e.file_id (+) = df.file_id
	AND      
	df.file_id  = f.file_id (+)
	and 
	df.tablespace_name='&TABLESPACE_NAME'
ORDER BY 
	df.tablespace_name,
	Df.file_name;

alter database tempfile '&tempfilename' resize &Size_In_GB G;