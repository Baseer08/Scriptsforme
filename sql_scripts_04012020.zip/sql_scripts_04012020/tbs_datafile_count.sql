set linesize 200
set pagesize 200
break on tbs_type skip 1
col tablespace_name format a30
col size_gb format 999,999.99
clear scr
With A as 
(
	select 
		(select 'Oracle Tablespaces:' from dual) as TBS_type, 
		tablespace_name,
		count(*) as datafiles,
		sum(bytes)/1024/1024/1024 as size_GB 
	from 
		dba_data_files 
	where 
		tablespace_name in ('SYSTEM','SYSAUX','USERS') or tablespace_name like 'UNDO%' 
	group by 
		rollup(tablespace_name)
	union all
	select 
		(select 'Application Tablespaces:' from dual) as TBS_type, 
		tablespace_name, 
		count(*) as datafiles,
		sum(bytes)/1024/1024/1024 as size_GB
	from
		dba_data_files 
	where 
		tablespace_name not in ('SYSTEM','SYSAUX','USERS') 
		and tablespace_name not like 'UNDO%' 
		and tablespace_name not like '%WPS%'
		and tablespace_name not like '%QUEST%'
		and tablespace_name not like '%AUDTBS%'
		and tablespace_name not like '%PERFSTAT%'
		and tablespace_name not like '%DBUTILS%'
	group by 
		rollup(tablespace_name)
	union all
	select 
		(select 'Temporary Tablespace' from dual) as TBS_type,  
		tablespace_name, 
		count(*) as datafiles,
		sum(bytes)/1024/1024/1024 as size_GB
	from 
		dba_temp_files 
	group by 
		rollup(tablespace_name)
	union all
	select 
		(select 'WPS Tablespaces: ' from dual) as TBS_type, 
		tablespace_name,
		count(*) as datafiles,
		sum(bytes)/1024/1024/1024 as size_GB 
	from 
		dba_data_files 
	where 
		tablespace_name like '%WPS%'
		or tablespace_name like '%QUEST%'
		or tablespace_name like '%AUDTBS%'
		or tablespace_name like '%PERFSTAT%' 
		or tablespace_name like '%DBUTILS%'
	group by 
		rollup(tablespace_name)
)
select a.TBS_type, nvl(a.tablespace_name,'************************Total:') as tablespace_name, a.datafiles, size_gb  from A 
order by 1,3;