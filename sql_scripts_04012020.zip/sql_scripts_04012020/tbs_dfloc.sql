set linesize 120
set pagesize 200 
col df_location format a40
select distinct regexp_substr(name,'^.*/') as df_location from v$datafile order by 1;
--select distinct regexp_substr(name,'^.*/') as df_location, round(bytes/1024/1024/1024) as Size_GB, file# from v$datafile order by 1;
select distinct  '!df -g ' || regexp_substr(name,'^.*/') as statement from v$datafile order by 1;
--select distinct  '!df -h ' || regexp_substr(name,'^.*/') as statement from v$datafile order by 1;

