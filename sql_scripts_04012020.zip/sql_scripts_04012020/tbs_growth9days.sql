break on tsname skip 1
set linesize 200 pagesize 200
col curent_size_GB format 9,999.99
col USEDSIZE_GB format 9,999.99
SELECT 
	ts.tsname, 
	TO_CHAR (sp.begin_interval_time,'DD-MM-YYYY') days, 
	max(round((tsu.tablespace_size* dt.block_size )/(1024*1024*1024),2) ) cur_size_GB,
	max(round((tsu.tablespace_usedsize* dt.block_size )/(1024*1024*1024),2)) usedsize_GB
FROM 
	DBA_HIST_TBSPC_SPACE_USAGE tsu, 
	DBA_HIST_TABLESPACE_STAT ts, 
	DBA_HIST_SNAPSHOT sp, 
	DBA_TABLESPACES dt
WHERE 
	tsu.tablespace_id= ts.ts#
	AND tsu.snap_id = sp.snap_id
	AND ts.tsname = dt.tablespace_name
	AND ts.tsname NOT IN ('SYSAUX','SYSTEM','USERS','UNDOTBS1')
GROUP BY 
	TO_CHAR (sp.begin_interval_time,'DD-MM-YYYY'), ts.tsname 
ORDER BY 
	ts.tsname, 
	days;