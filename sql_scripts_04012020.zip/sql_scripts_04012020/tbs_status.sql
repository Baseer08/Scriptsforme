set linesize 200 pagesize 200
col tablespace_name formata a30
select tablespace_name, status from dba_tablespaces order by 1;