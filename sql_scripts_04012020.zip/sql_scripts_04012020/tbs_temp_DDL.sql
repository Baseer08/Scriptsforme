set linesize 200
	set pagesize 200
	With tbs as
	(SELECT /* + RULE */
		df.tablespace_name AS TBS_NAME, 
		round(df.bytes / (1024 * 1024 * 1024)) AS Total_Size_GB,
		round(Trunc(fs.bytes / (1024 * 1024 * 1024))) AS Free_Size_GB
	FROM 
		(SELECT 
		tablespace_name,
		Sum(ALLOCATED_SPACE) AS bytes
	FROM 
		dba_temp_free_space
	GROUP BY tablespace_name) fs,
		(SELECT 
		tablespace_name,
		SUM(bytes) AS bytes
		FROM 
			dba_temp_files
		where 
			tablespace_name not in ('SYSTEM','SYSAUX','USERS', 'TEMP','UNDOTBS1','UNDOTBS2')
		GROUP BY 
			tablespace_name) df
	WHERE 
		fs.tablespace_name = df.tablespace_name)
	select
		'Create temporary tablespace ' ||TBS_NAME ||';' as command
		--free_SIZE_GB
	from
		tbs
	order by
		1;