set linesize 200
set pagesize 60
select 'alter database datafile ''' || file_name || ''' autoextend on next 1G maxsize unlimited;' as stmt from dba_data_files
union 
select 'alter database tempfile ''' || file_name || ''' autoextend on next 1G maxsize unlimited;' as stmt from dba_temp_files;