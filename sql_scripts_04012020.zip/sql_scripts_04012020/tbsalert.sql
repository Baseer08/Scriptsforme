SET FEEDBACK OFF
SET VERIFY OFF
set linesize 120
col name format a10
define PERC = &1
with
        DB as
                (select name from v$database),
        TBS as
                (select
                                tablespace_name ||' tablespace is '|| PUSED ||'%  Used. ' as TBS_Usage
                from
                                (
                                Select
                                                a.tablespace_name,
                                                b.T_size/1024/1024/1024 as Total_GB,
                                                (b.t_size-a.f_size)/1024/1024/1024 as Used_GB,
                                                a.F_size/1024/1024/1024 as Free_GB,
                                                round(((b.t_size-a.f_size)/b.T_size)*100,2) as PUSED,
                                                100-round(((b.t_size-a.f_size)/b.T_size)*100,2) as PFree
                                from
                                (select tablespace_name, sum(bytes) as F_size from dba_free_space group by tablespace_name) a,
                                (select tablespace_name, sum(bytes) as T_size from dba_data_files group by tablespace_name) b
                                where
                                                a.tablespace_name=b.tablespace_name
                                )
                where
                                PUSED > &PERC)
select
        DB.name as DBName,
        TBS.TBS_Usage
from
        DB,
        TBS;